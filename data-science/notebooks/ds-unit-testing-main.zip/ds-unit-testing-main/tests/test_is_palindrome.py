#import the libraries we use
import pytest
#import the python file we want to test (* means all in that file)
from src.unit_test_examples.palindrom import *


#write the pytest with parametrization and test_<function_name> as name
@pytest.mark.parametrize("maybe_palindrome, expected_result", [
    ("", True),
    ("a", True),
    ("Bob", True),
    ("Never odd or even", True),
    ("Do geese see God?", True),
    ("abc", False),
    ("abab", False),
])
def test_is_palindrome(maybe_palindrome, expected_result):
    assert is_palindrome(maybe_palindrome) == expected_result